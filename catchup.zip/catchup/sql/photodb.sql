-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2024 at 05:27 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `photosdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `m_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `date` varchar(30) NOT NULL,
  `imname` varchar(100) NOT NULL,
  `imname2` varchar(100) NOT NULL,
  `imname3` varchar(100) NOT NULL,
  `imname4` varchar(100) NOT NULL,
  `imname5` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`m_id`, `name`, `date`, `imname`, `imname2`, `imname3`, `imname4`, `imname5`) VALUES
(1, 'Technex', '9-April-2024', '09_Apr_2024_19_07_05.jpg', '09_Apr_2024_19_07_052.jpg', '09_Apr_2024_19_07_053.jpg', '09_Apr_2024_19_07_054.jpg', '09_Apr_2024_19_07_055.jpg'),
(2, 'INSIGHT', '14-April-2024', '09_Apr_2024_20_21_51.jpg', '09_Apr_2024_20_21_512.jpg', '09_Apr_2024_20_21_513.jpg', '09_Apr_2024_20_21_514.jpg', '09_Apr_2024_20_21_515.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`m_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
