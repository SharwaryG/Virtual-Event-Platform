<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>email</title>
    <script type="text/javascript"
        src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js">
    </script>
    <link href="fontawesome/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="email.css">

</head>

<body>
    <header class="header">
        <a href="#" class="logo">CatchUp</a>
        <nav class="nav-items">
                <a href="home1.php">Home</a>
                <a href="meeting1.php">Meeting</a>
                <a href="event form/data_display.php">Verify Client</a>
                <a href="Exhibition/Project/upload_fe.php">Create Events</a>
                <a href="Exhibition/Project/viewmenu.php">Exhibition</a>
                <a href="email.php">Send Emails</a>
                <a href="faq2.php">FaQ</a>
                <a href="php/logout.php">Log Out</a>
            </nav>
    </header>

    <div class="wrapper-event">
        <!-- <span class="icon-close"> <i class="fa-solid fa-xmark"></i></span> -->
        <div class="form-box">
            <h2>Email</h2>
            <div style="width: 100%; height: 1.5px; background-color: #ab8686; opacity: 0.5;"></div>
            <div class="event-box">
                <div class="container">
                    <h3>Sender</h3>
                    <input type="text" placeholder="sender" id="sender" name="sender" required><br>
                    <h3>To(Email)</h3>
                    <input type="text" placeholder="email to" name="to" id="to" required><br>
                    <h3>Subject</h3>
                    <input type="text" placeholder="Subject" id="subject" name="subject" required><br>
                    <h3>Reply to</h3>
                    <input type="text" placeholder="Email address" id="replyto" name="replyto" required><br>
                    <h3>Message</h3>
                    <textarea name="" id="message" cols="30" rows="10"></textarea><br>
                    <button class="btnlogin-popup" onclick=sendMail()>Send Email</button>
                </div>

            </div>
        </div>
        <div class="wrapper">
            <!-- <span class="icon-close"> <i class="fa-solid fa-xmark"></i></span> -->
            <div class="form-box ">
                <h2>Users</h2>
                <div style="width: 100%; height: 1.5px; background-color: #ab8686; opacity: 0.5; margin-bottom: 7px;"></div>

                <div class="form-box1">
                    <?php
                    $serverr = "localhost";
                    $userr = "root";
                    $passwd = "";
                    $dbh = "catchup";

                    $connn = mysqli_connect($serverr, $userr, $passwd, $dbh);
                    // Check connection
                    if ($connn->connect_error) {
                        die("Connection failed: " . $connn->connect_error);
                    }

                    $sql = "SELECT * FROM users";
                    $result = mysqli_query($connn, $sql);

                    $result = $connn->query($sql);
                    if ($result) {
                        $i = 1;
                        while ($row = $result->fetch_row()) {
                            echo "<hr><span>User ", $i, " ", $row[2], "</span><br>";
                            $i++;
                        }
                        $result->free_result();
                    }


                    $connn->close();
                    ?>

                </div>
            </div>

        </div>
        <script src="email.js"></script>
</body>

</html>