<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Frequently Asked Questions</title>
    <link rel="stylesheet" href="style2.css">

</head>

<body>

    <!-- Header -->
    <header class="header">
    <div style="margin-left: 50px;">
      <a href="#" class="logo">CatchUp</a>
    </div>
    <div style="margin-right: 50px;">
    <nav class="nav-items">
                <a href="home1.php">Home</a>
                <a href="meeting1.php">Meeting</a>
                <a href="event form/data_display.php">Verify Client</a>
                <a href="Exhibition/Project/upload_fe.php">Create Events</a>
                <a href="Exhibition/Project/viewmenu.php">Exhibition</a>
                <a href="email.php">Send Emails</a>
                <a href="faq2.php">FaQ</a>
                <a href="php/logout.php">Log Out</a>
            </nav>
    </div>
  </header>

    <div class="faq">
        <div class="inside">


            <ul id="Catchup">
                <li>
                    <label for="first">What is Catchup ? <span>&#9830</span></label>
                    <input type="radio" name="Catchup" id="first">
                    <div class="content">
                        <p>
                            Catchup is a Virtual event platform where you can explore various events like meetings,
                            exhibhition,
                            virtual events, competitions and many more.
                        </p>

                    </div>
                </li>
                <li>
                    <label for="second">Which technical equipment is required for Catchup? <span>&#9830</span></label>
                    <input type="radio" name="Catchup" id="second">
                    <div class="content">
                        <p>
                            Things you’ll require when attending or hosting a virtual or hybrid event on CatchUp are a
                            high-speed internet connection, a desktop/laptop. Catchup works on all browsers. If you are
                            the
                            speaker, you might require a webcam and microphone for the best experience.
                        </p>
                    </div>
                </li>
                <li>
                    <label for="third">What type of events can organize on Catchup? <span>&#9830</span></label>
                    <input type="radio" name="Catchup" id="third">
                    <div class="content">
                        <p>
                            Events like Meetings, Webinars, Conferences, Competitions, Exhibitions, etc can be organize
                            on
                            the
                            platform.
                        </p>

                    </div>
                </li>
                <li>
                    <label for="fourth">How can I ask for help in CatchUp? <span>&#9830</span></label>
                    <input type="radio" name="Catchup" id="fourth">
                    <div class="content">
                        <p>
                            If you want any help regarding CatchUp you can mail your querry on the given email id.
                        </p>
                    </div>
                </li>
                <li>
                    <label for="fifth">Can I use CatchUp on multiple browsers? <span>&#9830</span></label>
                    <input type="radio" name="Catchup" id="fifth">
                    <div class="content">
                        <p>
                            Catchup is browser and device agnostic. However, for the best experience, it is important to
                            use
                            CatchUp on a laptop or a desktop.
                        </p>

                    </div>
                </li>

            </ul>
        </div>
    </div>

    <!-- Footer  -->
    <div class="footer">
        <div class="content">
            <div class="services">
                <h4>Quick Links</h4>
                <p><a href="home.php">Home</a></p>
                <p><a href="calendar.php">Event Calender</a></p>
                <p><a href="meeting.php">Meeting</a></p>
                <p><a href="faq.php">FaQ</a></p>

            </div>
            <div class="social-media">
                <h4>Social</h4>
                <p>
                    <a><i class="fab fa-linkedin"></i> Linkedin</a>
                </p>
                <p>
                    <a><i class="fab fa-github"></i> Github</a>
                </p>
                <p>
                    <a><i class="fab fa-facebook"></i> Facebook</a>
                </p>
                <p>
                    <a><i class="fab fa-instagram"></i> Instagram</a>
                </p>
            </div>
            <div class="links">
                <h4>Quick links</h4>
                <p><a href="#">Ask Us</a></p>
                <p><a href="#">About Us</a></p>
                <p><a href="#">Privacy policy</a></p>
                <p><a href="#">Terms and conditions</a></p>
            </div>
            <div class="details">
                <h4 class="address">Address</h4>
                <p>
                    Nagpur, India
                </p>
                <h5 class="mobile">Mobile</h5>
                <p><a href="#">+91-1234554321</a></p>
                <h5 class="mail">Email</h5>
                <p><a href="#">catchup@gmail.com</a></p>
            </div>
        </div>
        <footer>
            <hr />
            © Copywright 2023 CatchUp. All rights reserved.
        </footer>
    </div>
    </div>
    </footer>


</body>

</html>