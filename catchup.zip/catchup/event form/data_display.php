<?php
    include('menu.html');
?>

<?php
// Database configuration
$conn = mysqli_connect('localhost', 'root', '', 'catchup');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Number of records per page
$records_per_page = 3;

// Get the current page number from the URL parameter
if (isset($_GET['page']) && is_numeric($_GET['page'])) {
    $page = $_GET['page'];
} else {
    $page = 1;
}

// Calculate the offset for the SQL query
$offset = ($page - 1) * $records_per_page;

// Fetch data from the database with pagination
$sql = "SELECT * FROM form LIMIT $offset, $records_per_page";
$result = $conn->query($sql);

// Check if there are any records
if ($result->num_rows > 0) {
    echo "<div class='record-container'>";

    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        echo "<div class='record'>";
        echo "<div>ID: <span>" . $row["id"] . "</span></div>";
        echo "<hr>";
        echo "<div>Name: <span>" . $row["name"] . "</span></div>";
        echo "<div>Email: <span>" . $row["email"] .  "</span></div>";
        echo "<div>Phone: <span>" . $row["phone"] . "</span></div>";
        echo "<div>Adhar: <span>" . $row["adhar"] . "</span></div>";
        echo "<hr>";
        echo "<div>Identity Proof: <br> <img src='" . $row["identity_proof_photo"] . "' width='200' height='100'></div>";
        echo "<hr>";
        echo "<div>Proof of Event: <br> <img src='" . $row["proof_of_event"] . "' width='200' height='100'></div>";
        echo "<hr>";
        echo "<div>Status: <span>" . $row["status"] . "</span></div>";
        echo "<div class='record-actions'>";
        echo "<button onclick='updateStatus(" . $row["id"] . ")' class='update-btn'>Update Status</button>";
        echo "<button onclick='rejectEntry(" . $row["id"] . ")' class='reject-btn'>Reject</button>";
        echo "</div>";
        echo "</div>";
    }

    echo "</div>";
} else {
    echo "<div class='no-results'>0 results</div>";
}

// Pagination links
$sql_total = "SELECT COUNT(*) AS total FROM form";
$result_total = $conn->query($sql_total);
$row_total = $result_total->fetch_assoc();
$total_pages = ceil($row_total["total"] / $records_per_page);

echo "<div class='pagination'>";
echo "<span> Pages: &nbsp; </span>";
for ($i = 1; $i <= $total_pages; $i++) {
    echo "<a href='?page=$i'>$i</a> ";
}
echo "</div>";

// Close connection
$conn->close();
?>

<script>
    function updateStatus(id) {
        var confirmed = confirm("Are you sure you want to update the status?");
        if (confirmed) {
            // Send an AJAX request to update the status
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState == XMLHttpRequest.DONE) {
                    if (xhr.status == 200) {
                        // Reload the page after successful status update
                        window.location.reload();
                    } else {
                        // Handle error
                        console.error("Error updating status: " + xhr.responseText);
                    }
                }
            };
            xhr.open("GET", "update_status.php?id=" + id, true);
            xhr.send();
        }
    }

    function rejectEntry(id) {
        var confirmed = confirm("Are you sure you want to reject this entry?");
        if (confirmed) {
            // Send an AJAX request to reject the entry
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState == XMLHttpRequest.DONE) {
                    if (xhr.status == 200) {
                        // Reload the page after successful rejection
                        window.location.reload();
                    } else {
                        // Handle error
                        console.error("Error rejecting entry: " + xhr.responseText);
                    }
                }
            };
            xhr.open("GET", "reject_entry.php?id=" + id, true);
            xhr.send();
        }
    }
</script>

<style>
    .record-container {
        display: flex;
        flex-wrap: wrap;
        /* justify-content: space-between; */
        margin: 30px;
        /* margin-bottom: -20px; */
        margin-left: 100px;
    }

    .record {
        width: 322px;
        height: 600px;
        /* margin-bottom: 20px; */
        border: 2px solid #ab8686;
        padding: 10px;
        margin-right: 40px;
    }

    .record-field {
        margin-bottom: 5px;
    }

    .field-label {
        font-weight: bold;
    }

    .field-value {
        margin-left: 10px;
    }

    .record-actions {
        margin-top: 10px;
        justify-content: center;
        align-items: ;
    }

    .btn-update,
    .btn-reject {
        padding: 5px 10px;
        margin-right: 5px;
        cursor: pointer;
    }

    .update-btn {
        background-color: greenyellow;
        color: white;
        border-color: greenyellow;
        border-radius: 4px;
        height: 35px;
        width: auto;
        /* padding: 7px; */
        margin-right: 15px;
        align-items: center;
        /* padding: ; */
    }

    .reject-btn {
        background-color: red;
        color: white;
        border-color: red;
        border-radius: 4px;
        height: 35px;
        width: auto;
        /* padding: 7px; */
        margin-right: 15px;
    }

    .pagination {
        margin-top: 20px;
        display: flex;
        justify-content: center;
        font-weight: 600;
        margin-bottom: 20px;
    }

    .pagination span {
    
    }

    .pagination a {
        text-decoration: none;
        color: #333;
        margin-right: 5px;
        padding: 5px;
        background-color: #ab8686;
        border-radius: 3px;
    }

    .no-results {
        margin-top: 20px;
        font-style: italic;
        color: #999;
    }
</style>