<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Form</title>
    <style>
        /* CSS for header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #f5f5f5;
            margin: -10px;

        }

        .header .logo {
            font-size: 25px;
            font-family: 'Sriracha', cursive;
            color: #000;
            text-decoration: none;
            align-items: flex-start;
            margin-left: 10px;
            margin-right: 10vw;

        }

        .nav-items {
            display: flex;
            align-items: center;
            background-color: #f5f5f5;
            margin: auto;
            font-family: Georgia, 'Times New Roman', Times, serif;
            /* justify-content: space-between; */

        }

        .nav-items a {
            text-decoration: none;
            color: #000;
            padding: 25px 20px;

        }

        .btn1 {
            position: relative;
            display: flex;

        }

        .host-login {

            /* position: relative;
      padding: 0 10px;
      background-color: #ab8686;
      /* margin-right:10rem ; */

            /* align-items: flex-end;  */
            /* height: 40px;
      border-radius: 5px;
      border: 2px solid black; 
      font-family: Georgia, 'Times New Roman', Times, serif;
      margin-left:10rem ; */
            position: relative;
            /* margin-right: 30px; */
            padding: 0 10px;
            background-color: #ab8686;
            height: 40px;
            border-radius: 5px;
            font-family: Georgia, 'Times New Roman', Times, serif;
            border: 2px solid black;
            margin-left: 8px;

        }

        .host-login:hover {
            cursor: pointer;
            opacity: 0.5;
        }

        .attend-event {

            /* position: relative;
      padding: 0 10px;
      background-color: #ab8686;
      align-items: flex-end;   
      height: 40px;
      border-radius: 5px;
      font-family: Georgia, 'Times New Roman', Times, serif;
      margin-left:5px ;
      border: 2px solid black; 
      margin-right: 10; */
            position: relative;
            margin-right: 30px;
            padding: 0 10px;
            background-color: #ab8686;
            height: 40px;
            border-radius: 5px;
            font-family: Georgia, 'Times New Roman', Times, serif;
            border: 2px solid black;
            margin-left: 8px;



        }

        .attend-event:hover {
            cursor: pointer;
            opacity: 0.5;
        }

        .logout {

            position: relative;
            padding: 0 10px;
            background-color: #ab8686;
            align-items: flex-end;
            height: 40px;
            border-radius: 5px;
            font-family: Georgia, 'Times New Roman', Times, serif;
            margin-right: 2rem;
            border: 2px solid black;

        }

        .logout:hover {
            cursor: pointer;
            opacity: 0.5;
        }

        /* CSS for Form Elements */
        .formbox {
            height: 670px;
            width: 600px;
            margin-top: 3.5rem;
            margin-left: 20rem;
            border: 2px solid #ab8686;
            padding: 3rem;
            border-radius: 2rem;
            margin-bottom: 2rem;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            margin-top: 1rem;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="tel"],
        .form-group select {
            width: 80%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group select {
            width: 80%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url('data:image/svg+xml;utf8,<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M6 9l6 6 6-6"></path></svg>');
            background-position: right 10px top 50%;
            background-repeat: no-repeat;
            background-size: 12px;
        }

        .form-group small {
            display: block;
            margin-top: 5px;
            font-size: 12px;
            color: #888;
        }

        .form-group input[type="submit"] {
            background-color: #ab8686;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .form-group input[type="submit"]:hover {
            background-color: #ab8686;
        }
    </style>
</head>

<body>

    <header class="header">
        <div style="margin-left: 50px;">
            <a href="#" class="logo">CatchUp</a>
        </div>
        <div style="margin-right: 50px;">
            <nav class="nav-items">
                <a href="../home.php">Home</a>
                <a href="../meeting.php">Meeting</a>
                <a href="../Exhibition/User/viewevent.php">Exhibition</a>
                <a href="form.php">Client Enroll</a>
                <a href="../faq1.php">FaQ</a>
                <a href="../php/logout.php">Log Out</a>
            </nav>
        </div>
    </header>

    <!-- <h2>Event Registration Form</h2> -->
    <div class="formbox">
        <h2>Client Registration Form</h2>
        <div style="width: 100%; height: 1.5px; background-color: #ab8686"></div>
        <form action="formdb.php" method="post" enctype="multipart/form-data">

            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" required>
            </div>



            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" name="phone" pattern="[0-9]{10}" required>
            </div>

            <div class="form-group">
                <label for="adhar">Adhar Number <span>eg- xxxx xxxx xxxx</span></label><br>
                <input type="text" id="adhar" name="adhar" pattern="\d{4} \d{4} \d{4}" required><br>
            </div>

            <div class="form-group">
                <label for="identity_proof_photo">Upload Adhar Photo</label><br>
                <input type="file" id="identity_proof_photo" name="identity_proof_photo" accept="image/*" required><br>
            </div>

            <div class="form-group">
                <label for="event_name">Event Name</label>
                <input type="text" id="event_name" name="event_name" required>
            </div>

            <div class="form-group">
                <label for="proof_of_event">Proof of Event (Image)</label><br>
                <input type="file" id="proof_of_event" name="proof_of_event" accept="image/*" required><br>
            </div>

            <div class="form-group">
                <input type="submit" value="Submit">
            </div>
        </form>
    </div>

</body>

</html>