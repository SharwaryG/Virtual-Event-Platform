<?php
// Database configuration
$conn = mysqli_connect('localhost', 'root', '', 'catchup');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get ID parameter
$id = $_GET['id'];

// Update status to 'rejected'
$sql = "UPDATE form SET status='Rejected' WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Entry rejected successfully";
} else {
    echo "Error rejecting entry: " . $conn->error;
}

// Close connection
$conn->close();
?>
