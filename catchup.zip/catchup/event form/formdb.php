<?php
// Database configuration
$conn = mysqli_connect('localhost', 'root', '', 'catchup');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Escape and validate user inputs
    $name = $conn->real_escape_string($_POST['name']);
    $event_name = $conn->real_escape_string($_POST['event_name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $adhar = $conn->real_escape_string($_POST['adhar']);

    // Validate email and phone inputs
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format");
    }
    if (!preg_match("/^[0-9]{10}$/", $phone)) {
        die("Invalid phone number format");
    }
    if (!preg_match("/^\d{4} \d{4} \d{4}$/", $adhar)) {
        die("Invalid Aadhar number format. It should be in the format: xxxx xxxx xxxx");
    }

    // Handle file upload for identity proof and proof of event
    if (isset($_FILES["identity_proof_photo"]) && $_FILES["identity_proof_photo"]["error"] == 0 &&
        isset($_FILES["proof_of_event"]) && $_FILES["proof_of_event"]["error"] == 0) {

        $identity_proof_dir = "uploads/identity_proof/";
        $proof_of_event_dir = "uploads/proof_of_event/";

        $identity_proof_file = $identity_proof_dir . basename($_FILES["identity_proof_photo"]["name"]);
        $proof_of_event_file = $proof_of_event_dir . basename($_FILES["proof_of_event"]["name"]);

        $uploadOk = 1;

        // Validate file types and sizes
        $identity_proof_type = strtolower(pathinfo($identity_proof_file, PATHINFO_EXTENSION));
        $proof_of_event_type = strtolower(pathinfo($proof_of_event_file, PATHINFO_EXTENSION));

        $allowed_types = array("jpg", "jpeg", "png", "gif");
        if (!in_array($identity_proof_type, $allowed_types) || !in_array($proof_of_event_type, $allowed_types)) {
            die("Sorry, only JPG, JPEG, PNG & GIF files are allowed.");
        }

        if ($_FILES["identity_proof_photo"]["size"] > 500000 || $_FILES["proof_of_event"]["size"] > 500000) {
            die("Sorry, your files are too large.");
        }

        // Move uploaded files and insert data into database
        if (move_uploaded_file($_FILES["identity_proof_photo"]["tmp_name"], $identity_proof_file) &&
            move_uploaded_file($_FILES["proof_of_event"]["tmp_name"], $proof_of_event_file)) {
            $sql = "INSERT INTO form (name, event_name, email, phone, adhar, identity_proof_photo, proof_of_event)
                    VALUES ('$name', '$event_name', '$email', '$phone', '$adhar', '$identity_proof_file', '$proof_of_event_file')";
            if ($conn->query($sql) === TRUE) {
                // Success message and redirection
                echo "New record created successfully";
                exit; // Stop further execution
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Sorry, there was an error uploading your files.";
        }
    } else {
        echo "Please upload both identity proof and proof of event files.";
    }

    // Close connection
    $conn->close();
}
?>
