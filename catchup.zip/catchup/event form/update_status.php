<?php
// Database configuration
$conn = mysqli_connect('localhost', 'root', '', 'catchup');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the ID parameter is set
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prepare and execute the SQL query to update the status
    $sql = "UPDATE form SET status='Verified' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        // Status updated successfully
        echo "Status updated successfully";
    } else {
        // Error updating status
        echo "Error updating status: " . $conn->error;
    }
} else {
    // ID parameter is not set
    echo "ID parameter is missing";
}

// Close connection
$conn->close();
?>
