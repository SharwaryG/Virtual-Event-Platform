<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>
    <link rel="stylesheet" href="feedback.css">
</head>
<body>
    <div style="margin-left: 20px;">
        <a href="home.php"><button class="btn">Back</button></a>
    </div>
    <div class="container">
        <h2>Feedback Form</h2>
        <form action="submit_feedback.php" method="post">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="feedback">Feedback:</label>
            <textarea id="feedback" name="feedback" required></textarea>
            
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
