<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Meeting</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

  <style>
    @import url('https://fonts.googleapis.com/css2?family=Sriracha&display=swap');

    body {
      margin: 0;
      box-sizing: border-box;
    }

    /* CSS for header */
    .header {
      display: flex;
      background-color: #f5f5f5;
      align-items: center;
      justify-content: space-between;

    }

    .header .logo {
      font-size: 25px;
      font-family: 'Sriracha', cursive;
      color: #000;
      text-decoration: none;
      align-items: flex-start;
      margin-left: 10px;
      margin-right: 10vw;

    }

    .nav-items {
      display: flex;
      align-items: center;
      background-color: #f5f5f5;
      margin: auto;
      font-family: Georgia, 'Times New Roman', Times, serif;
      /* justify-content: space-between; */

    }

    .nav-items a {
      text-decoration: none;
      color: #000;
      padding: 35px 20px;

    }

    .btn1 {
      position: relative;
      margin: auto;
      display: flex;

    }

    .host-login {

      position: relative;
      padding: 0 10px;
      background-color: #ab8686;
      align-items: flex-end;
      height: 40px;
      border-radius: 5px;
      border: 2px solid black;
      font-family: Georgia, 'Times New Roman', Times, serif;

    }

    .host-login:hover {
      cursor: pointer;
      opacity: 0.5;
    }

    .attend-event {

      position: relative;
      padding: 0 10px;
      background-color: #ab8686;
      align-items: flex-end;
      height: 40px;
      border-radius: 5px;
      font-family: Georgia, 'Times New Roman', Times, serif;
      margin-left: 5px;
      border: 2px solid black;

    }

    .attend-event:hover {
      cursor: pointer;
      opacity: 0.5;
    }

    /* CSS for main element */
    .intro {
      display: flex;
      flex-direction: column;
      justify-content: center;
      float: right;
      align-items: center;
      width: 100%;
      height: 495px;
      background: linear-gradient(to bottom, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0.5) 100%);
      background-image: url(6.jpg);
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
    }

    .intro h1 {
      float: right;
      font-family: Georgia, 'Times New Roman', Times, serif;
      justify-content: right;
      font-size: 60px;
      color: #000;
      font-weight: bold;
      text-transform: uppercase;
      margin: 0;
    }

    .intro p {
      font-size: 20px;
      color: black;
      text-transform: uppercase;
      margin: 20px 0;
    }

    .intro button {
      background-color: #ab8686;
      color: #000;
      padding: 10px 25px;
      border: none;
      border-radius: 5px;
      font-size: 20px;
      font-weight: bold;
      cursor: pointer;
      box-shadow: 0px 0px 20px rgba(255, 255, 255, 0.4)
    }


    .about-me {
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 40px 80px;
      border-top: 2px solid #eeeeee;
    }

    .about-me img {
      width: 150px;
      max-width: 100%;
      height: auto;
      border-radius: 10px;
    }

    .about-me-text h2 {
      font-size: 30px;
      color: #ab8686;
      text-transform: uppercase;
      margin: 0;
    }

    .about-me-text p {
      font-size: 15px;
      color: #585858;
      margin: 9px 0;
    }



    .button {
      background-color: #ab8686;
      border: none;
      color: black;
      padding: 20px 34px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 20px;
      margin: 4px 2px;
      border-radius: 5px;
      cursor: pointer;
      font-family: Georgia, 'Times New Roman', Times, serif;
    }

    .footer {
      background-color: #ab8686;
      color: black;
      position: relative;
      width: 100%;
      bottom: 0;
      left: 0;
    }

    .footer .heading {
      color: black;
      max-width: 1010px;
      width: 90%;
      text-transform: uppercase;
      margin: 0 auto;
      margin-bottom: 3rem;
      font-family: Georgia, 'Times New Roman', Times, serif;
    }

    .footer .content {
      display: flex;
      align-items: center;
      justify-content: space-evenly;
      margin: 5rem 1rem 1rem 1rem;
    }

    .footer .content p {
      margin-bottom: 1.5rem;
    }

    .footer .content a {
      text-decoration: none;
      color: black;
    }

    .footer .content a:hover {
      border-bottom: 1px solid #971717;
    }

    .footer .content h4 {
      margin-top: 5rem;
      margin-bottom: 2rem;
      font-size: 19px;
    }

    /* footer {
  /* text-align: center; */
    /* margin-bottom: 2rem; 
} */

    footer hr {
      margin: 2rem 0;
    }

    @media (max-width: 767px) {
      .footer .content {
        display: flex;
        flex-direction: column;
        font-size: 14px;
      }

      .footer {
        position: unset;
      }
    }

    @media (min-width: 768px) and (max-width: 1024px) {

      .footer .content,
      .footer {
        font-size: 14px;
      }
    }

    @media (orientation: landscape) and (max-height: 500px) {
      .footer {
        position: unset;
      }
    }

  </style>

</head>

<body>
  <!-- Header -->
  <header class="header">
    <div style="margin-left: 50px;">
      <a href="#" class="logo">CatchUp</a>
    </div>
    <div style="margin-right: 50px;">
    <nav class="nav-items">
                <a href="home1.php">Home</a>
                <a href="meeting1.php">Meeting</a>
                <a href="event form/data_display.php">Verify Client</a>
                <a href="Exhibition/Project/upload_fe.php">Create Events</a>
                <a href="Exhibition/Project/viewmenu.php">Exhibition</a>
                <a href="email.php">Send Emails</a>
                <a href="faq.php">FaQ</a>
                <a href="php/logout.php">Log Out</a>
            </nav>
    </div>
  </header>

  
    <div class="intro">
      <a href="https://meet.google.com/" target="_blank" class="button">Create Meeting</a>
    </div>
  

  <!-- Footer -->
  <!-- <div class="footer">
    <div class="content">
      <div class="services">
        <h4>Quick Links</h4>
        <p><a href="home.php">Home</a></p>
        <p><a href="calendar.php">Event Calender</a></p>
        <p><a href="meeting.php">Meeting</a></p>
        <p><a href="faq.php">FaQ</a></p>

      </div>
      <div class="social-media">
        <h4>Social</h4>
        <p>
          <a><i class="fab fa-linkedin"></i> Linkedin</a>
        </p>
        <p>
          <a><i class="fab fa-github"></i> Github</a>
        </p>
        <p>
          <a><i class="fab fa-facebook"></i> Facebook</a>
        </p>
        <p>
          <a><i class="fab fa-instagram"></i> Instagram</a>
        </p>
      </div>
      <div class="links">
        <h4>Quick links</h4>
        <p><a href="#">Ask Us</a></p>
        <p><a href="#">About Us</a></p>
        <p><a href="#">Privacy policy</a></p>
        <p><a href="#">Terms and conditions</a></p>
      </div>
      <div class="details">
        <h4 class="address">Address</h4>
        <p>
          Nagpur, India
        </p>
        <h5 class="mobile">Mobile</h5>
        <p><a href="#">+91-1234554321</a></p>
        <h5 class="mail">Email</h5>
        <p><a href="#">catchup@gmail.com</a></p>
      </div>
    </div>
    <footer>
      <hr />
      © Copywright 2023 CatchUp. All rights reserved.
    </footer>
  </div>
  </div>
  </footer> -->


</body>

</html>