<?php 
 
 $con = mysqli_connect("localhost","root","","catchup") or die("Couldn't connect");

?>