<?php
session_start();

include ("php/config.php");
if (!isset($_SESSION['valid'])) {
  header("Location: index.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <script src="https://kit.fontawesome.com/c3d3886e8a.js" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/webfont/1.6.28/webfontloader.js"
    integrity="sha512-v/wOVTkoU7mXEJC3hXnw9AA6v32qzpknvuUF6J2Lbkasxaxn2nYcl+HGB7fr/kChGfCqubVr1n2sq1UFu3Gh1w=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <title>AdminHome</title>
</head>

<body>

  <!-- Header -->
  <header class="header">
    <div style="margin-left: 50px;">
      <a href="#" class="logo">CatchUp</a>
    </div>
    <div style="margin-right: 50px;">
      <nav class="nav-items">
        <a href="home1.php">Home</a>
        <a href="meeting1.php">Meeting</a>
        <a href="event form/data_display.php">Verify Client</a>
        <a href="Exhibition/Project/upload_fe.php">Create Events</a>
        <a href="Exhibition/Project/viewmenu.php">Exhibition</a>
        <a href="email.php">Send Emails</a>
        <a href="faq.php">FaQ</a>
        <a href="php/logout.php">Log Out</a>
      </nav>
    </div>
  </header>

  <?php

  $id = $_SESSION['id'];
  $query = mysqli_query($con, "SELECT*FROM adminuser WHERE Id=$id");

  while ($result = mysqli_fetch_assoc($query)) {
    $res_Uname = $result['Username'];
    $res_Email = $result['Email'];
    #$res_Age = $result['Age'];
    $res_id = $result['Id'];
  }

  ?>


  <main>

    <div class="intro">
      <h1>CatchUp</h1>
      <p>Let's catchup virtually</p>
    </div>

    <div class="about-me">
      <div class="about-me-text">
        <h2>About Us</h2>
        <p>CatchUp provides all kind of webinars, conferences, meeting and community events virtually. It will
          allow
          host to schedule an event and also will notify the attendees on the event day. Internal meeting
          tools are designed specifically to make internal conversations within the teams easy and quick like
          calling,
          video calling, emojis, white board, screen sharing and allows the attendees to chat, poll.
          And valuable feedback about the website will be taken from the participants.
        </p>
      </div>
      <img src="2.png" alt="me">
    </div>
  </main>

  <div class="wrapper">
    <div class="box">
      <div class="front-face">
        <div class="icon"><i class="fa-solid fa-user-large"></i></div>
        <span>Meeting</span>
      </div>
      <div class="back-face">
        <span>Meeting</span>
        <p>Meetings or virtual meetups can be done using the virtual event platform CatchUp. One to one meeting or group
          meeting can be organize on this platform. User can held the meeting according to their convinience anywhere
          and anytime.</p>
      </div>
    </div>
    <div class="box">
      <div class="front-face">
        <div class="icon"><i class="fa-solid fa-users-line"></i></div>
        <span>Conference</span>
      </div>
      <div class="back-face">
        <span>Conference</span>
        <p>Conference can be held with the help of CatchUp. Inviting people for attending the conferences on
          intellectual topics, discussing the problems regarding it can be discussed in conference.</p>
      </div>
    </div>
    <div class="box">
      <div class="front-face">
        <div class="icon"><i class="fa-solid fa-images"></i></div>
        <span>Exhibition</span>
      </div>
      <div class="back-face">
        <span>Exhibition</span>
        <p>Exhibitions are intresting and magnificient. Users can enjoy exhibition on the websites which can be
          organized by various artist. Exhibition like art exhibition, technology fairs, healthcare exhibition can be
          seen.</p>
      </div>
    </div>
  </div>


  </main>

  <!-- Footer -->
  <div class="footer">
    <div class="content">
      <div class="services">
        <h4>Quick Links</h4>
        <p><a href="home.php">Home</a></p>
        <p><a href="Exhibition/User/viewevent.php">Exhibition</a></p>
        <p><a href="meeting.php">Meeting</a></p>
        <p><a href="faq.php">FaQ</a></p>

      </div>
      <div class="social-media">
        <h4>Social</h4>
        <p>
          <a><i class="fab fa-linkedin"></i> Linkedin</a>
        </p>
        <p>
          <a><i class="fab fa-github"></i> Github</a>
        </p>
        <p>
          <a><i class="fab fa-facebook"></i> Facebook</a>
        </p>
        <p>
          <a><i class="fab fa-instagram"></i> Instagram</a>
        </p>
      </div>
      <div class="links">
        <h4>Quick links</h4>
        <p><a href="#">Ask Us</a></p>
        <p><a href="#">About Us</a></p>
        <p><a href="#">Privacy policy</a></p>
        <p><a href="#">Terms and conditions</a></p>
      </div>
      <div class="details">
        <h4 class="address">Address</h4>
        <p>
          Nagpur, India
        </p>
        <h5 class="mobile">Mobile</h5>
        <p><a href="#">+91-1234554321</a></p>
        <h5 class="mail">Email</h5>
        <p><a href="#">catchup@gmail.com</a></p>
      </div>
    </div>
    <footer>
      <hr />
      © Copywright 2023 CatchUp. All rights reserved.
    </footer>
  </div>
  </div>
  </footer>


</body>

</html>