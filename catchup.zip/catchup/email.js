function sendMail(){
  (function(){
     emailjs.init({
       publicKey: "XL4E0JMDzgfsIjhb7"
     });
  })();
  var param={
   sender:document.querySelector("#sender").value,
   to:document.querySelector("#to").value,
   subject:document.querySelector("#subject").value,
   replyto:document.querySelector("#replyto").value,
   message:document.querySelector("#message").value,

  };
  var serviceID="service_e82b9sw";
  var templateID="template_1lyvems";
  emailjs.send(serviceID,templateID,param)
  .then(res=>{
   alert("Email Sent");
  }).
  catch();}