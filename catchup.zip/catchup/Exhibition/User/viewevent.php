<?php 
  include("menu.html");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Photo Gallery</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body, html {
      margin: 0;
      padding: 0;
      height: 100%;
    }
    .container-fluid {
      padding: 0;
    }
    .carousel-item img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .carousel-caption {
      background: rgba(0, 0, 0, 0.7);
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      padding: 20px;
      color: white;
    }
    .carousel-caption h5 {
      margin-bottom: 10px;
      font-size: 1.5rem;
    }
    .carousel-caption span {
      font-size: 0.8rem;
      font-weight: 300;
    }
    .carousel-inner {
      height: 100%;
    }
    .carousel-item {
      height: 100%;
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row">
    <?php
      $conn=new mysqli('localhost','root','','photodb');
      $sql_obj=mysqli_query($conn,'select * FROM photos ORDER BY m_id DESC');
      $total_count=mysqli_num_rows($sql_obj);

      for($i=0; $i<$total_count; $i++) {
        $row=mysqli_fetch_assoc($sql_obj);
        $name=$row['name'];
        $date=$row['date'];
        $imname=$row['imname'];
        $imname2=$row['imname2'];
        $imname3=$row['imname3'];
        $imname4=$row['imname4'];
        $imname5=$row['imname5'];
    ?>
    <div class="col-md-12 col-lg-12">
      <div id="carouselExampleControls<?php echo $i; ?>" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="../images1/<?php echo $imname; ?>" alt="<?php echo $name; ?>">
          </div>
          <div class="carousel-item">
            <img src="../images1/<?php echo $imname2; ?>" alt="<?php echo $name; ?>">
          </div>
          <div class="carousel-item">
            <img src="../images1/<?php echo $imname3; ?>" alt="<?php echo $name; ?>">
          </div>
          <div class="carousel-item">
            <img src="../images1/<?php echo $imname4; ?>" alt="<?php echo $name; ?>">
          </div>
          <div class="carousel-item">
            <img src="../images1/<?php echo $imname5; ?>" alt="<?php echo $name; ?>">
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls<?php echo $i; ?>" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls<?php echo $i; ?>" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
        <div class="carousel-caption ">
          <h4>EVENT :<?php echo $name; ?></h4>
          <h6 style="font-weight:bolder">EVENT DATE :<?php echo $date; ?></h6>
        </div>
      </div>
    </div>
    <?php } ?>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
