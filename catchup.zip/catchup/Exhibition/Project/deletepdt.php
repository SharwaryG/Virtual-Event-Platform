<?php

// include_once('../shared/connection.php');
$conn=new mysqli('localhost','root','','photodb');

if(!isset($_GET['m_id']))
{
    echo "Missing Fields";
    die;
}
$m_id=$_GET['m_id'];

$sql_status=mysqli_query($conn,"delete from photos where m_id=$m_id");

if($sql_status)
{
    header('location:viewmenu.php');
}
else
{
    //header('location:error.php?msg='Sql error'');
    echo "Sql query failed";
}

?>
