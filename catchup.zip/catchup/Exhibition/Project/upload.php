<?php


    if(!isset($_FILES['pdt_image']) && !isset($_FILES['pdt_image2']) && !isset($_FILES['pdt_image3']) && !isset($_FILES['pdt_image4']) && !isset($_FILES['pdt_image5']) )
    {
        echo"<h3>Server Validation is failed !</h3>";
        die;
    }
    $name=$_POST['name'];
    $date=$_POST['date'];
    $img=$_FILES['pdt_image'];
    $img2=$_FILES['pdt_image2'];
    $img3=$_FILES['pdt_image3'];
    $img4=$_FILES['pdt_image4'];
    $img5=$_FILES['pdt_image5'];
    
    $error=$img['error'];
    if($error==1)
    {
        echo"<h3>Upload Failed try again </h3>";
        die;
    }
    $tmp_name=$img['tmp_name'];
    $tmp_name2=$img2['tmp_name'];
    $tmp_name3=$img3['tmp_name'];
    $tmp_name4=$img4['tmp_name'];
    $tmp_name5=$img5['tmp_name'];
    
    date_default_timezone_set('Asia/Kolkata');
    $date_str=date('d_M_Y_H_i_s').'.jpg';
    $date_str2=date('d_M_Y_H_i_s').'2.jpg';
    $date_str3=date('d_M_Y_H_i_s').'3.jpg';
    $date_str4=date('d_M_Y_H_i_s').'4.jpg';
    $date_str5=date('d_M_Y_H_i_s').'5.jpg';

    move_uploaded_file($tmp_name,"../images1/$date_str");
    move_uploaded_file($tmp_name2,"../images1/$date_str2");
    move_uploaded_file($tmp_name3,"../images1/$date_str3");
    move_uploaded_file($tmp_name4,"../images1/$date_str4");
    move_uploaded_file($tmp_name5,"../images1/$date_str5");

    $conn=new mysqli('localhost','root','','photodb');

    $cmd="insert into photos(name,date,imname,imname2,imname3,imname4,imname5) values('$name','$date','$date_str','$date_str2','$date_str3','$date_str4','$date_str5')";
    $sql_status=mysqli_query($conn,$cmd);

    if($sql_status)
    {
        header('location:upload_fe.php');
    }
    else
    {
        echo"<h3>Error in SQL syntax</h3>";
    }

   



?>