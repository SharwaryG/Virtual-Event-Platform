<?php 
  include("menu.html");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Photo Gallery</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .card {
      margin: 20px;
      border: none;
      border-radius: 1px;
      box-shadow: 0 4px 8px #ab8686;
    }
    .card-img-top {
      height: 200px;
      object-fit: cover;
      border-top-left-radius: 0px;
      border-top-right-radius: 0px;
    }
    .card-header {
      background-color: #ab8686;
      color: #fff;
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
      padding: 10px;
      text-align: center;
    }
    .btn-delete {
      background-color: #dc3545;
      border: none;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="row">
    <?php
      

      $conn=new mysqli('localhost','root','','photodb');

      $sql_obj=mysqli_query($conn,'select * FROM photos ORDER BY m_id DESC');

      $total_count=mysqli_num_rows($sql_obj);

      for($i=0; $i<$total_count; $i++) {
        $row=mysqli_fetch_assoc($sql_obj);
        $m_id=$row['m_id'];
        $name=$row['name'];
        $date=$row['date'];
        $imname=$row['imname'];
        $imname2=$row['imname2'];
        $imname3=$row['imname3'];
        $imname4=$row['imname4'];
        $imname5=$row['imname5'];
    ?>
    
      <div class="col-md-6 col-lg-4">
        <div class="card">
        <div class="card-header" ><h5><b><?php echo $name; ?></b></h5><span style="font-weight:thin"><?php echo $date; ?></span></div>
          <div id="carouselExampleControls<?php echo $i; ?>" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="../images1/<?php echo $imname; ?>" class="card-img-top" alt="Image 1">
              </div>
              <div class="carousel-item">
                <img src="../images1/<?php echo $imname2; ?>" class="card-img-top" alt="Image 2">
              </div>
              <div class="carousel-item">
                <img src="../images1/<?php echo $imname3; ?>" class="card-img-top" alt="Image 3">
              </div>
              <div class="carousel-item">
                <img src="../images1/<?php echo $imname4; ?>" class="card-img-top" alt="Image 4">
              </div>
              <div class="carousel-item">
                <img src="../images1/<?php echo $imname5; ?>" class="card-img-top" alt="Image 5">
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls<?php echo $i; ?>" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls<?php echo $i; ?>" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
          <div class="card-body">
            <div class="d-flex justify-content-between">
              <a href="deletepdt.php?m_id=<?php echo $m_id; ?>" class="btn btn-delete">Delete</a>
            </div>
          </div>
        </div>
      </div>
    <?php } ?>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
