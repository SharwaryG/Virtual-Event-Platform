<?php
    include('menu.html');
?> 

<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
    crossorigin="anonymous"></script>

  <style>
    .row {
      align-items: row;
    }

    body {
      background-color: #f8f9fa;
    }

    .container {
      max-width: 500px;
      margin: 50px auto;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0px 0px 10px #ab8686;
      background-color: #fff;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      font-weight: bold;
    }

    .custom-file-label::after {
      content: "Browse";
    }
  </style>
</head>

<body>
  <!-- <div class="d-flex justify-content-center align-items-center vh-100">
        
        <form action="upload.php" enctype="multipart/form-data" method="post" style="width:40%" class=" bg-warning p-4 text-center m-4" >
            
        <h3 style="font-weight: bolder;text-transform: uppercase;margin-left: 10px;">Upload Image</h3>

            <input  name="name" type="text" placeholder="Enter Event Name" class="form-control mt-4" autocomplete="off" required>
            <input  name="name" type="text" placeholder="Product name" class="form-control mt-4" autocomplete="off" required>
            <input  name="price" type="number" placeholder="Product price" class="form-control mt-4" autocomplete="off" required>

            <textarea required name="description" placeholder="Product description" cols="30" rows="3" class="mt-4 form-control" autocomplete="off"></textarea>
            <div class="row">
                <div style="display:flex;gap:20px;align-items:center">
                    <input name="pdt_image" type="file" accept="image/*" class="form-control mt-4" autocomplete="off" required>
                    <input name="pdt_image2" type="file" accept="image/*" class="form-control mt-4" autocomplete="off" required>
            
                </div>
                <div style="display:flex;gap:20px;">
                <input name="pdt_image3" type="file" accept="image/*" class="form-control mt-4" autocomplete="off" required>
                <input name="pdt_image4" type="file" accept="image/*" class="form-control mt-4" autocomplete="off" required>
            
                </div>
                <div style="display:flex;gap:10px;margin-left:25%">
                    <input name="pdt_image5" type="file" accept="image/*" class="form-control mt-4" autocomplete="off" required>
                </div>
                    
                <input style="width:30%;"  type="submit" value="UPLOAD" class="form-control mt-4 btn btn-outline-primary">
            </div>
        </form>


    </div> -->
  <div class="container">
    <h2 class="text-center mb-3">Event Form</h2>
    <div style="width: 100%; height: 1px; background-color: #ab8686; margin-bottom: 15px;"></div>
    <form action="upload.php" method="post" enctype="multipart/form-data">
      <div class="d-flex" style="gap:20px">
        <div class="form-group">
          <label for="name">EVENT:</label>
          <input type="text" class="form-control" placeholder="Ex. Technex" name="name" autocomplete="off" required>
        </div>
        <div class="form-group">
          <label for="date">DATE:</label>
          <input type="date" class="form-control" placeholder="Ex. 10-January-2024" name="date" autocomplete="off"
            required>
        </div>
      </div>

      <!-- <div style="width: 100%; height: 1px; background-color: #ab8686; margin-bottom: 15px;"></div> -->
      <div class="d-flex" style="gap:20px">
        <div class="form-group">
          <label>EVENT IMAGES:</label> <br>
          <label for="file1">File 1:</label>
          <div class="custom-file">
            <input type="file" class="custom-file-input" accept="image/*" name="pdt_image" autocomplete="off" required>
            <label class="custom-file-label" for="file1">Choose file</label>
          </div>
        </div>

        <div class="form-group" style="margin-top:32px">
          <label for="file2">File 2:</label>
          <div class="custom-file">
            <input type="file" class="custom-file-input" name="pdt_image2" accept="image/*" autocomplete="off" required>
            <label class="custom-file-label" for="file2">Choose file</label>
          </div>
        </div>
      </div>

      <div class="d-flex" style="gap:20px">
        <div class="form-group">
          <label for="file3">File 3:</label>
          <div class="custom-file">
            <input type="file" class="custom-file-input" name="pdt_image3" accept="image/*" autocomplete="off" required>
            <label class="custom-file-label" for="file3">Choose file</label>
          </div>
        </div>

        <div class="form-group">
          <label for="file4">File 4:</label>
          <div class="custom-file">
            <input type="file" class="custom-file-input" name="pdt_image4" accept="image/*" autocomplete="off" required>
            <label class="custom-file-label" for="file4">Choose file</label>
          </div>
        </div>
      </div>

      <div class="form-group">
        <label for="file5">File 5:</label>
        <div class="custom-file">
          <input type="file" class="custom-file-input" name="pdt_image5" accept="image/*" autocomplete="off" required>
          <label class="custom-file-label" for="file5">Choose file</label>
        </div>
      </div>
      <button type="submit" value="UPLOAD" class="upload-btn">Upload</button>
    </form>
  </div>
  <script>
    // Update the label text to display the name of the file after it has been selected
    document.querySelectorAll('.custom-file-input').forEach(function (input) {
      input.addEventListener('change', function (event) {
        var fileName = event.target.files[0].name;
        var label = event.target.nextElementSibling;
        label.innerText = fileName;
      });
    });
  </script>
</body>
<style>
  .upload-btn {
    width: 440px;
    height: 40px;
    border-radius: 5px;
    color: white;
    background-color: #ab8686;
    border-color: #ab8686;
    font-weight: 600;
  }

  .upload-btn:hover 
  {
    border-color: #ab8686;
    background-color: white;
    color: #ab8686;
  }
</style>

</html>